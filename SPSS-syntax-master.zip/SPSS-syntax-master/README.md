# SPSS-syntax
